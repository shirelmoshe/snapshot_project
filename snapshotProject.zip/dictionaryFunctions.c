#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "typesStructs.h"
#include "oneSnapShot.h"
#include "dictionaryFunctions.h"
#include "log.h"
#pragma warning(disable:4996)

dictionaryDLL* dictionaryDLL_Head = NULL;
dictionaryDLL* dictionaryDLL_Tail = NULL;

int countnewDictionaryDLL = 0;
int notExistsDLLInList = 0;
char* nameDH = "";

//Creates single-valued processes linked list
//add the first snapshot
void dictionaryProcess(snapshot* snapShotList) {
	LogEvent("the function dictionaryProcess  has started");
	
	FirstProcess = 1;

	snapshot* currSnapShot = snapShotList;
	
	while (currSnapShot != NULL) {

		
		PROCESS* currProcess = currSnapShot->myprocess;


		while (currProcess != NULL) {

			
			addProcess(currProcess);


			
			currProcess = currProcess->next;
		}

		currSnapShot = currSnapShot->next;
	}
	LogEvent("the function dictionaryProcess has ended");
}



//Creates single-valued dictionary dll linked list
//add the first process in a single-valued process linked list
void dictionaryDLLFunction(PROCESS* sortProcessList) {
	LogEvent("the function dictionaryDLLFunction  has started");
	PROCESS* currentPro = sortProcessList;
	PROCESS* OldcurrentPro;


	dictionaryDLL* currentDictionaryDLL1 = dictionaryDLL_Head;
	DLLName* currentCheckDLL = sortProcessList->dll;

	
	while (currentPro != NULL)
	{
		
		currentCheckDLL = currentPro->dll;
		while (currentCheckDLL != NULL)
		{
			
			currentDictionaryDLL1 = dictionaryDLL_Head;
			while (currentDictionaryDLL1 != NULL)
			{
				
				if (strcmp(currentCheckDLL->nameOfDLL, currentDictionaryDLL1->nameOfDLL) == 0)
				{
					notExistsDLLInList = 1;

				
					checkDictionaryDLL(currentCheckDLL, currentPro);
				
					currentDictionaryDLL1 = dictionaryDLL_Tail;
				}
				currentDictionaryDLL1 = currentDictionaryDLL1->next; 
			}

			
			if (notExistsDLLInList != 1)
			{
				
				addDictionaryDLL(currentCheckDLL, currentPro);

			}

			currentCheckDLL = currentCheckDLL->next;

			
			notExistsDLLInList = 0;
		}

		OldcurrentPro = currentPro;
		currentPro = currentPro->next;
		free(OldcurrentPro);
	}
	LogEvent("the function dictionaryDLLFunction  has ended");
}


//adds the dll which does not exist in th list to the dictionary dll linkad list
//the function add the dll and the process that used him
void addDictionaryDLL(DLLName* nameSortDLL, PROCESS* processSortDLL) {
	LogEvent("the function addDictionaryDLL  has started");
	
	if (nameSortDLL == NULL && processSortDLL == NULL)
	{
		
		countnewDictionaryDLL = 0;
		dictionaryDLL_Head = NULL;
		return;
	}


	dictionaryDLL* newDictionaryDLL = (dictionaryDLL*)malloc(sizeof(dictionaryDLL));
	if (!newDictionaryDLL)
	{
		LogError(strerror(GetLastError()));
		return;
	}

	
	countnewDictionaryDLL++;
	newDictionaryDLL->countDictionaryDLL = countnewDictionaryDLL;

	
	createsdictionaryProcess(processSortDLL);

	
	newDictionaryDLL->dictionaryProcessTail = processDictionary_Tail;
	newDictionaryDLL->dictionaryProcessUsed = processDictionary_Head;
	strcpy(newDictionaryDLL->nameOfDLL, nameSortDLL->nameOfDLL);

	
	newDictionaryDLL->next = NULL;
	if (dictionaryDLL_Head == NULL) {
		dictionaryDLL_Head = newDictionaryDLL;
		dictionaryDLL_Tail = newDictionaryDLL;
		newDictionaryDLL->prev = NULL;
	}
	else {
		dictionaryDLL_Tail->next = newDictionaryDLL;
		newDictionaryDLL->prev = dictionaryDLL_Tail;
		dictionaryDLL_Tail = newDictionaryDLL;
	}

	
	createsdictionaryProcess(NULL);
	
	LogEvent("the function addDictionaryDLL has ended");
}




//Checking the location of the dictionary dll which is equal to dll in process
//and adds the process to the dictionary process linked list in dictionary dll
//the function add the dll and the process
void checkDictionaryDLL(DLLName* dDLL, PROCESS* newProDictionary)
{
	LogEvent("the function checkDictionaryDLL  has started");
	dictionaryDLL* moveDictionaryDLL = dictionaryDLL_Head;

	while (moveDictionaryDLL != NULL)
	{
		if (strcmp(moveDictionaryDLL->nameOfDLL, dDLL->nameOfDLL) == 0)
		{
			
			addingProcessDictionary(moveDictionaryDLL, newProDictionary);
			moveDictionaryDLL = dictionaryDLL_Tail;
		}

		moveDictionaryDLL = moveDictionaryDLL->next;
	}

	LogEvent("the function checkDictionaryDLL has ended");

}