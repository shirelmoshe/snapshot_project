#include <stdio.h>
#include <string.h>
#include <time.h>
#include "typesStructs.h"
#include "PageHTML.h"
#include "oneSnapShot.h"
#include "dictionaryFunctions.h"
#include "CalculationsFunction.h"
#include "dinamicHomePage.h"
#include "PageDLL.h"

#pragma warning(disable:4996)


int countDLLPageHTML = 0;
extern PROCESS* sortListProcess = NULL;

char* dynamicNav(int DLLCountHTML, int ProceessCountHTML, SIZE_T MemoryAvgHTML)
{
	LogEvent("the function dynamicNav  has started");
	char* dataNav = (char*)malloc(sizeof(long));
	dataNav[0] = NULL;
	if (!dataNav)
	{
		//error
		return;
	}
	sprintf(dataNav, "\n<div> Dll's cnt: %d </div>\n<div> Processes cnt: %d </div>\n<div> Memory avg: %d </div>\n", DLLCountHTML, ProceessCountHTML, MemoryAvgHTML);


	return dataNav;
	LogEvent("the function dynamicNav has ended");
}




void HtmlPage()//The function creates the DLL page
{
	LogEvent("the function HtmlPage has started");
	
	countOfCreateFiledllPage = 0;

	addProcess(NULL);

	
	addDictionaryDLL(NULL, NULL);

	
	dictionaryProcess(snapshot_Head);//Creates a singly linked list of PROCESS

	
	sortListProcess = PROCESS_Head;

	int amountProcesses = PROCESS_Tail->countProcess;

	
	dictionaryDLLFunction(sortListProcess);


	int amountDictionaryDLL = dictionaryDLL_Tail->countDictionaryDLL;

	
	SIZE_T averageProcessM = (SIZE_T)memoryAvgForALLSnapshot();


	char* dataNav = dynamicNav(amountDictionaryDLL, amountProcesses, averageProcessM);

	ResetHomePage = 1;

	firstOccurrenceInTheFile = 1;
	
	dynamicNavHtml("main.html", dataNav);

	dictionaryDLL* currDD = dictionaryDLL_Head;
	firstOccurrenceInTheFile = 0;
	while (currDD != NULL)
	{
		
		char* titleDLL = dinamicTitleProcessesUsed(currDD);//create title for the page

		
		char* tableDLL = dinamicTableProcessesUsed(currDD);//create table 

	
		dynamicTitleHtml("dllPage.html", tableDLL, titleDLL);

	
		firstOccurrenceInTheFile = 0;
		currDD = currDD->next;
	}

	
	char* nameF = dynamicHtml("main.html", dynamicDLLTable(dictionaryDLL_Head), NULL);//Saving the dll table on the home page
	LogEvent("the function HtmlPage  has ended");
}


char* dinamicTitleProcessesUsed(dictionaryDLL* oneDictionaryDLL)//the function Creates the title of used processes count in one dictionary dll
{
	LogEvent("the function dinamicTitleProcessesUsed has started");
	char* titelProcesses = (char*)malloc(100);
	titelProcesses[0] = NULL;
	if (!titelProcesses)
	{
		//error
		return;
	}
	sprintf(titelProcesses, "<h1> %d process used </h1>", oneDictionaryDLL->dictionaryProcessTail->counterDictionaryProcess);


	return titelProcesses;
	LogEvent("the function dinamicTitleProcessesUsed has ended");
}








char* dynamicDLLTable(dictionaryDLL* D_DLLHeadHtml)////Creates the table of single-valued dlls
{
	LogEvent("the function dynamicDLLTable  has started");
	dictionaryDLL* currDictionaryDLL = D_DLLHeadHtml;
	char* dataDLLTable = (char*)malloc(500);
	char* allTheOptions = (char*)malloc(sizeof(dictionaryDLL) * dictionaryDLL_Tail->countDictionaryDLL + 100);
	if (!allTheOptions)
	{
		//error
		return;
	}
	allTheOptions[0] = NULL;
	while (currDictionaryDLL != NULL)
	{
		
		countDLLPageHTML++;

		if (!dataDLLTable)
		{
			//error
			return;
		}
		sprintf(dataDLLTable, "\n<tr>\n<td> %s </td >\n<td ><a href = \"useDll_%d.html\" >dll%d.html</a></td>\n</tr>\n", currDictionaryDLL->nameOfDLL, countDLLPageHTML, countDLLPageHTML);

		currDictionaryDLL = currDictionaryDLL->next;

	
		strcat(allTheOptions, dataDLLTable);	//Connects each line that is created 
	}
	free(dataDLLTable);

	
	return allTheOptions;
	LogEvent("the function dynamicDLLTable  has ended");
}








char* dinamicTableProcessesUsed(dictionaryDLL* oneDictionaryDLL)//The function creates a table of the PROCESS that uses the DLL
{
	LogEvent("the function dinamicTableProcessesUsed  has started");
	processDictionary* processesOfDDLL = oneDictionaryDLL->dictionaryProcessUsed;
	char* tableProcesses = (char*)malloc(10000);
	tableProcesses[0] = NULL;
	char* allTheOptions = (char*)malloc(sizeof(processDictionary) * oneDictionaryDLL->dictionaryProcessTail->counterDictionaryProcess + 100000);
	allTheOptions[0] = NULL;
	if (!allTheOptions)
	{
		//error
		return;
	}
	while (processesOfDDLL != NULL)
	{

		if (!tableProcesses)
		{
			//error
			return;
		}
		sprintf(tableProcesses, "\n<tr>\n<td> %d </td>\n<td> %s </td>\n</tr>\n", processesOfDDLL->counterDictionaryProcess, processesOfDDLL->nameOfProcess);
		processesOfDDLL = processesOfDDLL->next; \

			strcat(allTheOptions, tableProcesses);
	}
	free(tableProcesses);

	
	return allTheOptions;
	LogEvent("the function dinamicTableProcessesUsed  has ended");
}


