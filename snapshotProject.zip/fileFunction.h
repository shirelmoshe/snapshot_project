void InsertingASnapshotIntoAFile();
void snapshotLoadFromFile();
