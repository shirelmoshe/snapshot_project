void resetCollections(snapshot* headSanpSot);
void deleteDictionay();

extern int restet;
