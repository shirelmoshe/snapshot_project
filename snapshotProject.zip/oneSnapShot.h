void addDLL(char dllName[]);
void addProcess(PROCESS* processNew);
void addOneSnapShot(snapshot* newSnapShotFromFile);
void SortingBetweenTwoProcessCountDLL();

void PrintCount();
void PrintListDictionary();
#pragma once


