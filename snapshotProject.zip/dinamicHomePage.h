
char* dynamicNav(int DLLCountHTML, int ProceessCountHTML, SIZE_T MemoryAvgHTML);
char* dynamicDLLTable(dictionaryDLL* D_DLLHeadHtml);
char* dinamicTitleProcessesUsed(dictionaryDLL* oneDictionaryDLL);
char* dinamicTableProcessesUsed(dictionaryDLL* oneDictionaryDLL);