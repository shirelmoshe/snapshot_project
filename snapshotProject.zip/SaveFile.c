#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "PageHTML.h"
#include "log.h"
#pragma warning(disable:4996)


FILE* file;
FILE* fileR;
int countOfCreateFilesnapshot = 1;
int countOfCreateFiledllPage = 1;


//know which file to open
char* newNameOfFile = 0;


char* readFromFile() {
	LogEvent("the function  readFromFile  has started");

	if (firstOccurrenceInTheFile == 0 && strcmp(nameFile, "main.html") != 0)
	{
		fileR = fopen(nameFile, "r");
		if (!fileR)
		{
			return NULL;
		}

	}
	else if (ResetHomePage == 0 && firstOccurrenceInTheFile == 0)
	{
		fileR = fopen(nameFile, "r");
		if (!fileR)
		{
			return NULL;
		}
	}
	else if (strcmp(nameFile, "main.html") == 0)
	{
		fileR = fopen("homePage.html", "r");
		if (!fileR)
		{
			LogError(strerror(GetLastError()));
			return 0;
		}
	}
	else if (strcmp(nameFile, "snapshot.html") == 0)
	{
		fileR = fopen(newNameOfFile, "r");
		if (!fileR)
		{
			LogError(strerror(GetLastError()));
			return 0;
		}
	}
	else if (strcmp(nameFile, "dllPage.html") == 0)
	{
		fileR = fopen(newNameOfFile, "r");
		if (!fileR)
		{
			LogError(strerror(GetLastError()));
			return 0;
		}
		
	}



	// Get the file size
	char* charCount = (char*)malloc(10000);
	if (!charCount)
	{
		return 1;
	}
	char* read;
	int fileSize = 0;
	while ((read = fgets(charCount, 1000, fileR)))
	{
		fileSize += strlen(charCount);
	}

	free(charCount);
	fclose(fileR);
	fileSize += 2;




	// alloc space as file size
	char* inThefile = (char*)malloc(fileSize);
	if (!inThefile)
	{
		return 1;
	}




	if (firstOccurrenceInTheFile == 0 && strcmp(nameFile, "main.html") != 0)
	{
		fileR = fopen(nameFile, "r");
		if (!fileR)
		{
			return NULL;
		}

	}
	else if (ResetHomePage == 0 && firstOccurrenceInTheFile == 0)
	{
		ResetHomePage = 1;
		fileR = fopen(nameFile, "r");
		if (!fileR)
		{
			return NULL;
		}
	}
	else if (strcmp(nameFile, "main.html") == 0)
	{
		fileR = fopen("homePage.html", "r");
		if (!fileR)
		{
			LogError(strerror(GetLastError()));
			return 0;
		}
	}
	else if (strcmp(nameFile, "snapshot.html") == 0)
	{
		fileR = fopen(newNameOfFile, "r");
		if (!fileR)
		{
			LogError(strerror(GetLastError()));
			return 0;
		}
	}
	else if (strcmp(nameFile, "dllPage.html") == 0)
	{
		fileR = fopen(newNameOfFile, "r");
		if (!fileR)
		{
			LogError(strerror(GetLastError()));
			return 0;
		}
	}

	int readPosition = 0;
	char charToRead;
	while ((charToRead = fgetc(fileR)) != EOF)
	{
		inThefile[readPosition] = charToRead;
		readPosition++;
	}
	inThefile[readPosition] = NULL;


	fclose(fileR);
	return inThefile;
	LogEvent("the function  readFromFile  has ended");

}




char* saveInToFileHTML(char* newFile)
{
	LogEvent("the function  saveInToFileHTML  has started");
	if (strcmp(nameFile, "main.html") == 0)
	{
		file = fopen("homePage.html", "w");
		if (!file)
		{
			LogError(strerror(GetLastError()));
			return 1;
		}

		//The file (newName) was opened successfully
		fputs(newFile, file);
		fclose(file);

	}
	else if (strcmp(nameFile, "snapshot.html") == 0)
	{
		file = fopen(newNameOfFile, "w");
		if (!file)
		{
			LogError(strerror(GetLastError()));
			return 1;
		}

		//The file (newName) was opened successfully
		fputs(newFile, file);
		fclose(file);
	}
	else if (strcmp(nameFile, "dllPage.html") == 0)
	{
		file = fopen(newNameOfFile, "w");
		if (!file)
		{
			LogError(strerror(GetLastError()));
			return 1;
		}

		//The file (newName) was opened successfully
		fputs(newFile, file);
		fclose(file);
	}
	else
	{
		
		LogError(strerror(GetLastError()));
		return 1;
	}
	free(newFile);
	return newNameOfFile;
	LogEvent("the function  saveInToFileHTML  has ended");
}







char* createNewName(char* nameOfOriginFile) {
	LogEvent("the function  createNewName has started");
	char* newNameFile = (char*)malloc(30);

	if (strcmp(nameOfOriginFile, "snapshot.html") == 0)
	{
		sprintf(newNameFile, "samplePage_%d.html", countOfCreateFilesnapshot);
		countOfCreateFilesnapshot++;

		return newNameFile;
	}
	else if (strcmp(nameOfOriginFile, "dllPage.html") == 0)
	{
		sprintf(newNameFile, "useDll_%d.html", countOfCreateFiledllPage);
		countOfCreateFiledllPage++;

		return newNameFile;
	}
	else
	{
		return NULL;
	}
	LogEvent("the function  createNewName  has ended");
}