#pragma once
void doingMalloc();
void headerSnapShotDetails();
void headerProcessDetails();
void headerDLLDetails();
