#pragma once
void getMemoryInfo(DWORD processID);
void getProcessesInfo();
