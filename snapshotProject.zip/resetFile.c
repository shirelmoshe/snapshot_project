#include <stdlib.h> 
#include <stdio.h>
#include <time.h>
#include "typesStructs.h"
#include "resetCollectionsFile.h"
#include "structHeaderFunction.h"
#include "PageHTML.h"
#include "log.h"
#pragma warning(disable:4996)


void resetCollections(snapshot* headSanpSot)
{
	LogEvent("the function  resetCollections has started");
	firstOccurrenceInTheFile = 0;
	ResetHomePage = 0;
	
	saveInToFileHTML(readFromFile());
	restet = 1;
	doingMalloc();
	snapshot* currentSnapShot = headSanpSot;
	PROCESS* currentProcess;
	DLLName* currentDLL;
	snapshot* previousSnapshot;
	PROCESS* previousProcess;
	DLLName* previousDLL;
	while (currentSnapShot != NULL)
	{
		currentProcess = currentSnapShot->myprocess;
		while (currentProcess != NULL)
		{
			currentDLL = currentProcess->dll;
			while (currentDLL != NULL)
			{
				previousDLL = currentDLL;
				currentDLL = currentDLL->next;
				free(previousDLL);
			}

			previousProcess = currentProcess;
			currentProcess = currentProcess->next;
			free(previousProcess);

		}

		previousSnapshot = currentSnapShot;
		currentSnapShot = currentSnapShot->next;
		free(previousSnapshot);

	}
	LogEvent("the function  resetCollections has ended");
}