#include <stdlib.h> 
#include <stdio.h>
#include <time.h>
#include "typesStructs.h"
#include "oneSnapShot.h"
#include "createsAprocess.h"
#include "structHeaderFunction.h"
#include "typesFilesHeader.h"
#include "CalculationsFunction.h"
#include "PageHTML.h"
#include "displayFunction.h"
#include "log.h"

#pragma warning(disable:4996)

snapshot* snapshot_Head = NULL;
snapshot* snapshot_Tail = NULL;

int countOfSnapsNumber = 0;
int downloadFromAFile = 0;
int titleOfProcesses = 0;



void addOneSnapShot(snapshot* newSnapShotFromFile)//The function links the new snapshot to the linked list
{
	LogEvent("The function addOneSnapShot has started ");
	newSnapShot = (snapshot*)malloc(sizeof(snapshot));
	if (!newSnapShot)
	{
		LogError(strerror(GetLastError()));
		exit(1);
	}

	
	addProcess(NULL);//reset the PROCESS_Head 

	
	if (downloadFromAFile == 0)
	{
		LogEvent(" the function creatingHtml has started");
		
		getProcessesInfo();//creates a linked list of processors

		
		SortingBetweenTwoProcessCountDLL();//The function sorts a linked list according to the amount of DLLs

	
		newSnapShot->myprocess = PROCESS_Head;
		newSnapShot->counterProcess = PROCESS_Tail->countProcess;
	}
	else
	{
		LogEvent("enter to condition of load form file");
		newSnapShot = newSnapShotFromFile;//Adds the snapshot from the file
	}


	++countOfSnapsNumber;
	
	
	newSnapShot->counterOfSnapsNumber = countOfSnapsNumber;//add the snapshot number 

	
	strcpy(newSnapShot->snapshotTime, timeOfSnapshot);

	newSnapShot->next = NULL;

	
	if (snapshot_Head == NULL)//links the new snapshot to the linked list
	{

		snapshot_Head = newSnapShot;
		snapshot_Tail = newSnapShot;
		newSnapShot->prev = NULL;
	}
	else
	{
		snapshot_Tail->next = newSnapShot;
		newSnapShot->prev = snapshot_Tail;
		snapshot_Tail = newSnapShot;
	}

	//creates a header struct for snapshots
	headerSnapShotDetails();
	
	
	

	
	if (downloadFromAFile == 0) creatingHtml();//creates an html page for processes 
	LogEvent("The function creatingHtml has ended");
}

void creatingHtml() ///The function creates an html page for processes 
{
	LogEvent("the function creatingHtml has started");

	firstOccurrenceInTheFile = 0;


	char* temporaryHTML = processesTable(newSnapShot);//creating a dynamic process table



	char* temporaryTitle = processesTitle(newSnapShot);//creating a dynamic process title


	char* linkToSample = dynamicTitleHtml("snapshot.html", temporaryHTML, temporaryTitle);//creates page for all the processes in snapshot

	free(temporaryHTML);

	firstOccurrenceInTheFile = 0;


	char* dynamicLineTable = SnapShotTable(newSnapShot, linkToSample, addingDll(newSnapShot), memoryAverage(newSnapShot));
	free(linkToSample);

	char* nameF = dynamicHtml("main.html", dynamicLineTable, NULL);

	LogEvent("the function creatingHtml has ended");

}



void headerSnapShotDetails()//The function creates a header struct

{
	LogEvent("the function headerSnapShotDetails has started");
	 
	snapshotFile->versionSnapShot = versionOfSnapShot;//Update version

	
	snapshotFile->countSnapshot = snapshot_Tail->counterOfSnapsNumber;

	
	snapshotFile->reserve[20] = NULL;
	LogEvent("the function headerSnapShotDetails has ended");
}




