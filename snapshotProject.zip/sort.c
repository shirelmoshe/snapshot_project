#include <stdio.h>
#include <stdlib.h> 
#include "typesStructs.h"
#include"oneSnapShot.h"
#include "log.h"
#pragma warning(disable:4996)


void PrintList()
{
	LogEvent("the function  PrintList has started");
	PROCESS* processMoves = PROCESS_Head;
	PROCESS* print = PROCESS_Head;

	while (processMoves != NULL)
	{
		print = processMoves;
		processMoves = processMoves->next;
		printf("the number is %d\n", print->DLLNumber);
		

	}
	
	printf("\n\n\n");
	LogEvent("the function  PrintList has ended");
}

void PrintCount()
{
	LogEvent("the function PrintCount has started");
	PROCESS* moveprocess = PROCESS_Head;
	PROCESS* print = PROCESS_Head;

	while (moveprocess != NULL)
	{
		print = moveprocess;
		moveprocess = moveprocess->next;
		printf("the countProcess is %d\n", print->countProcess);
		

	}
	printf("the tail is %d\n", PROCESS_Tail->countProcess);
	LogEvent("the function  PrintCount has ended");
}


void PrintListDictionary()
{
	LogEvent("the function  PrintListDictionary has started");
	dictionaryDLL* movedictionaryDLL = dictionaryDLL_Head;
	dictionaryDLL* print = dictionaryDLL_Head;

	while (movedictionaryDLL != NULL)
	{
		print = movedictionaryDLL;
		movedictionaryDLL = movedictionaryDLL->next;
		printf("the number is %s\n", print->nameOfDLL);
		

	}
	
	printf("\n\n\n");
	LogEvent("the function PrintListDictionary has ended");
}

void replaceBetweenTwoProcess(PROCESS* processToChange)
{
	LogEvent("the function  replaceBetweenTwoProcess has started");
	PROCESS* changeProcess = processToChange;
	int numOfProcess;

	if (changeProcess == NULL)
	{
		//There are no numbers
	}
	else if (changeProcess->next == NULL)
	{
		
	}
	else if (changeProcess == PROCESS_Head && changeProcess->next == PROCESS_Tail)
	{
		
		numOfProcess = changeProcess->countProcess;
		changeProcess->countProcess = changeProcess->next->countProcess;
		changeProcess->next->countProcess = numOfProcess;
		changeProcess->next = NULL;
		changeProcess->prev = PROCESS_Tail;
		PROCESS_Tail->prev = NULL;
		PROCESS_Tail->next = changeProcess;
		PROCESS_Tail = changeProcess;
		PROCESS_Head = changeProcess->prev;

		//only two numbers
	}
	else if (changeProcess == PROCESS_Head)
	{
		numOfProcess = changeProcess->countProcess;
		changeProcess->countProcess = changeProcess->next->countProcess;
		changeProcess->next->countProcess = numOfProcess;
		changeProcess->next->prev = NULL;
		changeProcess = changeProcess->next->next;
		PROCESS_Head->next->next = PROCESS_Head;
		PROCESS_Head->prev = PROCESS_Head->next;
		PROCESS_Head->next = changeProcess;
		changeProcess->prev = PROCESS_Head;
		PROCESS_Head = PROCESS_Head->prev;
		changeProcess = PROCESS_Head->next;
		//change from the beginning

	}
	else if (changeProcess->next == PROCESS_Tail)
	{
		
		numOfProcess = changeProcess->countProcess;
		changeProcess->countProcess = changeProcess->next->countProcess;
		changeProcess->next->countProcess = numOfProcess;
		changeProcess->next->prev = changeProcess->prev;
		changeProcess->prev = PROCESS_Tail;
		PROCESS_Tail->next = changeProcess;
		changeProcess->next = NULL;
		PROCESS_Tail->prev->next = changeProcess->prev;
		PROCESS_Tail = PROCESS_Tail->next;

		//change the tail
	}
	else
	{
		numOfProcess = changeProcess->countProcess;
		changeProcess->countProcess = changeProcess->next->countProcess;
		changeProcess->next->countProcess = numOfProcess;
		changeProcess->next->prev = changeProcess->prev;
		changeProcess->prev = changeProcess->next;
		changeProcess->next = changeProcess->next->next;
		changeProcess->prev->next = changeProcess;
		changeProcess->prev->prev->next = changeProcess->prev;
		changeProcess->next->prev = changeProcess;

		
	}

	LogEvent("the function  replaceBetweenTwoProcess has ended");
}

void SortingBetweenTwoProcessCountDLL()
{

	LogEvent("the function  SortingBetweenTwoProcessCountDLL has started");
	PROCESS* curreProcess = PROCESS_Head;
	if (!curreProcess)
	{
		
		return;
	}

	char change = 1;
	while (change != 0)
	{
		

		change = 0;
		while (curreProcess != NULL)
		{
			if (curreProcess->next != NULL && curreProcess->DLLNumber > curreProcess->next->DLLNumber)
			{
				
				replaceBetweenTwoProcess(curreProcess);
				change++;
			}
			curreProcess = curreProcess->next;
		}

		curreProcess = PROCESS_Head;
	}
	
	PrintList();
	LogEvent("the function SortingBetweenTwoProcessCountDLL has ended");
}