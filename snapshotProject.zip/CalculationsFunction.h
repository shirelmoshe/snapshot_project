#pragma once
int addingDll(snapshot* snapShot);
SIZE_T memoryAverage(snapshot* snapShot);
SIZE_T memoryAvgForALLSnapshot();
PROCESS* theGreatestMemory(snapshot* snapShot_html);
