#pragma once
char* SnapShotTable(snapshot* snapShot_html, char* fileNameHtml, int countDLLInSnapHTML, SIZE_T sizeOfMemoryHTML);
char* processesTitle(snapshot* snapShot_html);
char* processesTable(snapshot* snapShot_html);
char* dllTable(PROCESS* snapShot_html);