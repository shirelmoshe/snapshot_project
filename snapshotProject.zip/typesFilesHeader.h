#pragma once
extern char fileName[50];
#define versionOfSnapShot 1
#define versionOfProcess 1
#define versionOfDLL 1
extern int downloadFromAFile;
