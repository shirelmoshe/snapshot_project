#pragma once
void HtmlPage();
extern int countDLLPageHTML;
char* dynamicNavHtml(char* nameOfFile, char* addString);