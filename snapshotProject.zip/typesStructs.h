#include <windows.h>
#include <psapi.h>


typedef struct _DLLName {
	char nameOfDLL[300];
	int countDLL;
	struct _DLLName* next;
	struct _DLLName* prev;
}DLLName;

extern DLLName* DLLName_Head;
extern DLLName* DLLName_Tail;

typedef struct _DLLNameHeader {
	int versionDLLName;
	char reserve[20];
}DLLNameHeaders;


extern int counterDll;


typedef struct _PROCESS {
	char processName[300];
	DWORD PageFaultCount;
	SIZE_T WorkingSetSize;
	SIZE_T QuotaPeakPagedPoolUsage;
	SIZE_T QuotaPagedPoolUsage;
	SIZE_T PagefileUsage;
	DWORD processId;
	DLLName* dll;
	DLLName* dllTail;
	int DLLNumber;
	int countProcess;
	struct _PROCESS* prev;
	struct _PROCESS* next;

} PROCESS;


extern PROCESS* PROCESS_Head;
extern PROCESS* PROCESS_Tail;

typedef struct _processHeader {
	int versionProcess;
	char reserve[20];
} headerProcess;


extern int processCounter;


typedef struct _snapshot {
	PROCESS* myprocess;
	int counterOfSnapsNumber;
	int counterProcess;
	char snapshotTime[100];
	struct _snapshot* next;
	struct _snapshot* prev;
}snapshot;


typedef struct _snapshotHeader {
	int versionSnapShot;
	int countSnapshot;
	char reserve[20];
}headerSnaphsot;


extern snapshot* snapshot_Head;
extern snapshot* snapshot_Tail;



extern int FirstProcess;

//sign that the process entered the function checkListProcess
extern int existsProcessed;

extern int userResponse;
extern char timeOfSnapshot[100];


extern snapshot* newSnapShot;
extern PROCESS* newProcess;

extern headerSnaphsot* snapshotFile;
extern headerProcess* processFile;
extern DLLNameHeaders* DLLFile;



typedef struct _dictionaryProcess {
	char nameOfProcess[300];
	int counterDictionaryProcess;
	struct _dictionaryProcess* next;
	struct _dictionaryProcess* prev;
}processDictionary;


extern processDictionary* processDictionary_Head;
extern processDictionary* processDictionary_Tail;


typedef struct _dictionaryDLL {
	char nameOfDLL[300];
	int countDictionaryDLL;
	processDictionary* dictionaryProcessUsed;
	processDictionary* dictionaryProcessTail;
	struct _dictionaryDLL* next;
	struct _dictionaryDLL* prev;
}dictionaryDLL;


extern dictionaryDLL* dictionaryDLL_Head;
extern dictionaryDLL* dictionaryDLL_Tail;

#pragma onces

