#include <stdio.h>
#include "typesStructs.h"
#include "typesFilesHeader.h"
#include "fileFunction.h"
#include "oneSnapShot.h"
#include "resetCollectionsFile.h"
#include "PageHTML.h"
#include "structHeaderFunction.h"
#include "log.h"

#pragma warning(disable:4996)

snapshot* newSnapShot = NULL;
PROCESS* newProcess = NULL;

headerSnaphsot* snapshotFile = NULL;
headerProcess* processFile = NULL;
DLLNameHeaders* DLLFile = NULL;

char fileName[50] = "";



int restet = 0;
//Creates space to header structs
void doingMalloc()
{
	LogEvent("the function doingMalloc has started");
	//sign that resets the space to header structss
	if (restet == 1)
	{
		restet = 0;
		free(snapshotFile);
		free(processFile);
		free(DLLFile);
		return;
	}


	snapshotFile = (headerSnaphsot*)malloc(sizeof(headerSnaphsot));
	if (!snapshotFile)
	{
		LogError(strerror(GetLastError()));
		return;
	}

	processFile = (headerProcess*)malloc(sizeof(headerProcess));
	if (!processFile)
	{
		LogError(strerror(GetLastError()));
		return;
	}


	DLLFile = (DLLNameHeaders*)malloc(sizeof(DLLNameHeaders));
	if (!DLLFile)
	{
		LogError(strerror(GetLastError()));
		return;
	}
	LogEvent("the function doingMalloc  has ended");

}

void snapshotLoadFromFile()// the function reads from the file the header
{
	LogEvent("the function snapshotLoadFromFile  has started");
	printf("Please type a name for the file\n");
	scanf("%s", fileName);

	FILE* downloadableFile = fopen(fileName, "rb");
	if (!downloadableFile)
	{
		printf("The file did not open");
		return 1;
	}
	
	downloadFromAFile = 1;

	headerSnaphsot* downloadSnapshotHeader;
	downloadSnapshotHeader = (headerSnaphsot*)malloc(sizeof(headerSnaphsot));
	if (!downloadSnapshotHeader)
	{
		LogError(strerror(GetLastError()));
		return 1;
	}
	headerProcess* downloadProcessHeader;
	downloadProcessHeader = (headerProcess*)malloc(sizeof(headerProcess));
	if (!downloadProcessHeader)
	{
		LogError(strerror(GetLastError()));
		return 1;
	}
	DLLNameHeaders* downloadDllHeader;
	downloadDllHeader = (DLLNameHeaders*)malloc(sizeof(DLLNameHeaders));
	if (!downloadDllHeader)
	{
		LogError(strerror(GetLastError()));
		return 1;
	}


	snapshot* TheCurrentSnapshot;
	PROCESS* theCurrentProcess;
	DLLName* theCurrentDLL;

	int read = fread(downloadSnapshotHeader, sizeof(headerSnaphsot), 1, downloadableFile);
	if (!read)
	{
		LogError(strerror(GetLastError()));
		return 1;
	}

	read = fread(downloadProcessHeader, sizeof(headerProcess), 1, downloadableFile);
	if (!read)
	{
		LogError(strerror(GetLastError()));
		return 1;
	}

	read = fread(downloadDllHeader, sizeof(DLLNameHeaders), 1, downloadableFile);
	if (!read)
	{
		LogError(strerror(GetLastError()));
		return 1;
	}


	TheCurrentSnapshot = (snapshot*)malloc(sizeof(snapshot));
	if (!TheCurrentSnapshot)
	{
		LogError(strerror(GetLastError()));
		return 1;
	}

	theCurrentProcess = (PROCESS*)malloc(sizeof(PROCESS));
	if (!theCurrentProcess)
	{
		LogError(strerror(GetLastError()));
		return 1;
	}

	theCurrentDLL = (DLLName*)malloc(sizeof(DLLName));
	if (!theCurrentDLL)
	{
		LogError(strerror(GetLastError()));
		return 1;
	}

	for (int y = 0; y < downloadSnapshotHeader->countSnapshot; y++)
	{
		read = fread(TheCurrentSnapshot, sizeof(snapshot), 1, downloadableFile);
		if (!read)
		{
			LogError(strerror(GetLastError()));
			return 1;
		}

		addOneSnapShot(TheCurrentSnapshot);

		for (int i = 0; i < TheCurrentSnapshot->counterProcess; i++)
		{

			read = fread(theCurrentProcess, sizeof(PROCESS), 1, downloadableFile);
			if (!read)
			{
				LogError(strerror(GetLastError()));
				return 1;
			}

			addProcess(theCurrentProcess);

			for (int j = 0; j < theCurrentProcess->DLLNumber; j++)
			{

				read = fread(theCurrentDLL, sizeof(DLLName), 1, downloadableFile);
				if (!read)
				{
					LogError(strerror(GetLastError()));
					return 1;
				}

				addDLL(theCurrentDLL->nameOfDLL);
			}

			newProcess->dll = DLLName_Head;
			newProcess->dllTail = DLLName_Tail;
		}

		newSnapShot->myprocess = PROCESS_Head;
		newSnapShot->counterProcess = PROCESS_Tail->countProcess;

		//after it end reading Snapshot,creates html pages
		creatingHtml();
	}

	downloadFromAFile = 0;



	free(TheCurrentSnapshot);
	free(theCurrentProcess);
	free(theCurrentDLL);

	LogEvent("the function snapshotLoadFromFile has ended");
}


void InsertingASnapshotIntoAFile()
{
	LogEvent("the function  InsertingASnapshotIntoAFile  has started");
	int write;
	if (snapshotFile->versionSnapShot == NULL)
	{
		//the snapShotHeaderFile not exists
		printf("There are no  existing Snapshots");
		return;
	}
	printf("enter name for file\n");
	scanf("%s", fileName);
	FILE* f = fopen(fileName, "wb");
	if (!f)
	{
		printf("The file did not open");
		exit(1);
	}



	write = fwrite(snapshotFile, sizeof(headerSnaphsot), 1, f);
	if (!write)
	{
		LogError(strerror(GetLastError()));
		return;
	}
	write = fwrite(processFile, sizeof(headerProcess), 1, f);
	if (!write)
	{
		LogError(strerror(GetLastError()));
		return;
	}

	write = fwrite(DLLFile, sizeof(DLLNameHeaders), 1, f);
	if (!write)
	{
		LogError(strerror(GetLastError()));
		return;
	}


	snapshot* currentSnapShot = snapshot_Head;
	PROCESS* currentProcess = currentSnapShot->myprocess;
	DLLName* currentDLL = currentProcess->dll;

	while (currentSnapShot != NULL)
	{
		write = fwrite(currentSnapShot, sizeof(snapshot), 1, f);
		if (!write)
		{
			LogError(strerror(GetLastError()));
			return;
		}

		currentProcess = currentSnapShot->myprocess;

		while (currentProcess != NULL)
		{
			write = fwrite(currentProcess, sizeof(PROCESS), 1, f);
			if (!write)
			{
				LogError(strerror(GetLastError()));
				return;
			}

			currentDLL = currentProcess->dll;

			while (currentDLL != NULL)
			{
				write = fwrite(currentDLL, sizeof(DLLName), 1, f);
				if (!write)
				{
					LogError(strerror(GetLastError()));
					return;
				}

				currentDLL = currentDLL->next;
			}


			currentProcess = currentProcess->next;

		}

		currentSnapShot = currentSnapShot->next;
	}
	fclose(f);
	LogEvent("the function  InsertingASnapshotIntoAFile  has started");
}












