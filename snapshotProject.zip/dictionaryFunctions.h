void dictionaryProcess(snapshot* snapShotList);
void addDictionaryDLL(DLLName* nameSortDLL, PROCESS* processSortDLL);
void dictionaryDLLFunction(PROCESS* sortProcessList);

extern int countnewDictionaryDLL;

extern processDictionary* theDictionaryProcess;
void createsdictionaryProcess(PROCESS* useProcess);



void addingProcessDictionary(dictionaryDLL* locationDLL, PROCESS* namePro);
void checkDictionaryDLL(DLLName* dDLL, PROCESS* newProDictionary);