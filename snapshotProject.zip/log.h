#pragma once

void LogError(char message[100]);
void LogEvent(char message[100]);
