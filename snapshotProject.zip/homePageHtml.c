#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "PageHTML.h"
#include "PageDLL.h"
#include "log.h"
#pragma warning(disable:4996)


int firstOccurrenceInTheFile = 0;
int ResetHomePage = 0;
char seperator;
char nameFile[50] = "";

char* dynamicHtml(char* nameOfFile, char* addString, char* topHtml)
{

	LogEvent("the function dynamicHtml has started");
	strcpy(nameFile, nameOfFile);
	char* dynamicTable = addString;
	char* htmlFileTemplate = readFromFile();
	firstOccurrenceInTheFile = 1;
	char* found = "";
	int len;
	char* newFileSpace;

	if (topHtml == NULL)
	{
		if (countDLLPageHTML > 0) {
			countDLLPageHTML = 0;
			found = strstr(htmlFileTemplate, SEPERATOR_TEMP);
			len = found - htmlFileTemplate;
		}
		else
		{
			found = strstr(htmlFileTemplate, SEPERATOR);
			len = found - htmlFileTemplate;
		}
		newFileSpace = (char*)malloc(strlen(htmlFileTemplate) + 2 + strlen(dynamicTable));
		strncpy(newFileSpace, htmlFileTemplate, len);
		newFileSpace[len] = NULL;
	}
	else
	{

		found = strstr(htmlFileTemplate, SEPERATOR);
		newFileSpace = (char*)malloc(strlen(found) + strlen(topHtml) + 2 + strlen(dynamicTable));
		
		strcpy(newFileSpace, topHtml);
		
	}
	
	strcat(newFileSpace, dynamicTable);
	strcat(newFileSpace, found);
	char* nameForFile = saveInToFileHTML(newFileSpace);
	free(htmlFileTemplate);
	
	return nameForFile;

	LogEvent("the function dynamicHtml  has ended");

}





char* dynamicTitleHtml(char* nameOfFile, char* addString, char* title) {

	LogEvent("the function   has started");

	newNameOfFile = createNewName(nameOfFile);
	strcpy(nameFile, nameOfFile);
	char* dynamicTitle = title;
	char* htmlFileTemplate = readFromFile();

	char* found = strstr(htmlFileTemplate, SEPERATOR_TITLE);


	int len = found - htmlFileTemplate;
	char* newFileSpace = (char*)malloc(strlen(htmlFileTemplate) + 1 + strlen(dynamicTitle));
	if (!newFileSpace)
	{
		LogError(strerror(GetLastError()));
		return;
	}

	strncpy(newFileSpace, htmlFileTemplate, len);
	newFileSpace[len] = NULL;
	strcat(newFileSpace, dynamicTitle);
	char* found_2 = strstr(htmlFileTemplate, SEPERATOR);
	int len_2 = found_2 - found;
	strncat(newFileSpace, found, len_2);
	newFileSpace[len_2 + len + strlen(dynamicTitle)] = NULL;
	char* linkName = dynamicHtml(nameOfFile, addString, newFileSpace);


	free(htmlFileTemplate);

	return linkName;

	LogEvent("the function SnapShotTable  has started");
}



char* dynamicNavHtml(char* nameOfFile, char* addString) {

	LogEvent("the function SnapShotTable  has started");
	strcpy(nameFile, nameOfFile);
	char* dynamicTitle = addString;
	char* htmlFileTemplate = readFromFile();

	char* found = strstr(htmlFileTemplate, SEPERATOR_NAV);


	int len = found - htmlFileTemplate;
	char* newFileSpace = (char*)malloc(strlen(htmlFileTemplate) + 1 + strlen(dynamicTitle));
	if (!newFileSpace)
	{
		LogError(strerror(GetLastError()));
		return;
	}

	strncpy(newFileSpace, htmlFileTemplate, len);
	newFileSpace[len] = NULL;
	strcat(newFileSpace, dynamicTitle);
	strcat(newFileSpace, found);
	char* nameForFile = saveInToFileHTML(newFileSpace);


	free(htmlFileTemplate);

	return nameForFile;

	LogEvent("the function SnapShotTable  has started");
}