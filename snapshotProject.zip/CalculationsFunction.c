#include <stdlib.h> 
#include <stdio.h>
#include <time.h>
#include "typesStructs.h"
#include "CalculationsFunction.h"
#include "log.h"

#pragma warning(disable:4996)


//The function summarizes in each process the entire DLL
int addingDll(snapshot* snapShot) {
	LogEvent("the function  addingDll  has started");
	PROCESS* theNextProcess = snapShot->myprocess;
	long sumDll = 0;


	while (theNextProcess != NULL) {
		sumDll += theNextProcess->DLLNumber;
		theNextProcess = theNextProcess->next;
	}

	
	return sumDll;

	LogEvent("the function  addingDll has ended");
}


SIZE_T memoryAvgForALLSnapshot() //The function calculate average of all memory of processes that in all the snapshotns
{
	LogEvent("the function memoryAvgForALLSnapshot has started");
	snapshot* theNextSnapshot = snapshot_Head;
	PROCESS* moveProcess = theNextSnapshot->myprocess;
	SIZE_T averageOfMemory = 0;
	int sumProcess = 0;


	while (theNextSnapshot != NULL) {

		moveProcess = theNextSnapshot->myprocess;

		while (moveProcess != NULL) {
			sumProcess++;
			averageOfMemory += moveProcess->WorkingSetSize;

			moveProcess = moveProcess->next;
		}

		theNextSnapshot = theNextSnapshot->next;
	}
	averageOfMemory = averageOfMemory / sumProcess;


	return averageOfMemory;

	LogEvent("the function  memoryAvgForALLSnapshot  has ended");

}



PROCESS* theGreatestMemory(snapshot* snapShot_html) //The function Checks which process takes the most memory
{
	LogEvent("the function  ItheGreatestMemory has started");
	PROCESS* theProcess = snapShot_html->myprocess;
	PROCESS* retProcess = "";
	SIZE_T theBiggesMemory = snapShot_html->myprocess->WorkingSetSize;


	while (theProcess != NULL)
	{
		if (theProcess->WorkingSetSize > theBiggesMemory)
		{
			theBiggesMemory = theProcess->WorkingSetSize;
			retProcess = theProcess;
		}
		theProcess = theProcess->next;

	}


	return retProcess;
	LogEvent("the function  theGreatestMemory  has ended");
}



SIZE_T memoryAverage(snapshot* snapShot)  //The function calculate average of all memory of processes

{
	LogEvent("the function  memoryAverage  has started");

	PROCESS* moveProcess = snapShot->myprocess;
	SIZE_T averageOfMemory = 0;


	while (moveProcess != NULL) {
		averageOfMemory += moveProcess->WorkingSetSize;
		moveProcess = moveProcess->next;
	}

	averageOfMemory = averageOfMemory / snapShot->counterProcess;

	
	return averageOfMemory;
	LogEvent("the function  memoryAverage  has ended");
}





