#pragma once
void linkedListToCheck(PROCESS* CheckProcess);
void checkListDLL(PROCESS* currentProcess, DLLName* CheckDLL);
DLLName* originalListDLL(DLLName* TailOfExistDLL, DLLName* newList);